insert into acesso (cod_acesso, cod_estac, geom) 
values (1, 1,st_geomfromtext('LINESTRING(-53.71821624690131 -29.72203274495037, -53.71819746711388 -29.72213456573542)', 4326));

insert into acesso (cod_acesso, cod_estac, geom) 
values (2, 2,st_geomfromtext('LINESTRING(-53.71862509317749 -29.72209047817038,-53.7185889545379 -29.72223878535221)', 4326));

insert into acesso (cod_acesso, cod_estac, geom) 
values (3, 3,st_geomfromtext('LINESTRING(-53.71805413395862 -29.72350021269656, -53.71808077589144 -29.72335672475585,-53.7181032337885 -29.72322351317983)', 4326));
																			  
																										