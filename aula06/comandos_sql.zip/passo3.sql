insert into colegio (cod_col, telefone, nome, endereco, cep,bairro, estado, numero, geom) values('081.CPSM',
						32208273, 'Colégio Politécnico', 'Av. Roraima', 9700000, 'Camobi', 'RS',  1000, 
						   st_geomfromtext('point(-53.71819830653170 -29.72297182406500)', 4326));

