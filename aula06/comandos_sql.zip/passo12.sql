insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values
('A',1,7,0,5,1,1,1,'081.CPSM', st_geomfromtext('point(-53.71809591084416 -29.72244255431186)',4326));
 
insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values
('B',0,3,0,0,0,0,1,'081.CPSM',st_geomfromtext('point(-53.71840477785435 -29.7224001289419)',4326));
 
insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values 
('BAR',0,0,0,0,0,0,1,'081.CPSM',st_geomfromtext('point(-53.71790963571067 -29.7228310758635)',4326));
 
insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values
('C',2,2,1,2,0,0,1,'081.CPSM',st_geomfromtext('point(-53.71780283793987 -29.72230425862643)',4326));
 
insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values 
('D',3,2,2,0,0,0,1,'081.CPSM',st_geomfromtext('point(-53.71772726320468 -29.72256738519089)',4326));
 
insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values
('E',5,1,1,9,1,1,2,'081.CPSM',st_geomfromtext('point(-53.71771219786168 -29.72277514993818)',4326));
 
insert into predio(cod_pred,num_sala_aula,num_sala_adm,num_lab,num_sala_prof,num_banheiro_f,num_banheiro_m,num_andares,cod_col,geom) values 
('F',9,5,4,10,3,3,3,'081.CPSM',st_geomfromtext('point(-53.71777113037162 -29.72304453309505)',4326));
