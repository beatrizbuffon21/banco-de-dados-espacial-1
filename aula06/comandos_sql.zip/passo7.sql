create table vegetacao(cod_tipo integer PRIMARY KEY, 
			descricao character varying(50));
